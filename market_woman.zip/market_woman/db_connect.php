<?php
        //$id = $_GET['id']; 
	    $bvn = $_POST['bvn'];
        $nin = $_POST['nin'];
        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $email = $_POST['email'];
        $address = $_POST['address'];
    $conn = new mysqli('localhost' , 'root' , '' , 'mr_abbey');
    if($conn->connect_error){

        die('Connection Failed : ' .$conn->connect_error);

    }else{
        //die('fdfdf');
        if(isset($_GET['id'])){
            $id = $_GET['id'];
            //die('dfdf '.$id);
        }
                //updating the database

        $sqlstr= "UPDATE market SET bvn='$bvn', nin='$nin', firstname='$firstname', lastname='$lastname', email='$email', `address`='$address' WHERE ID='$id'";
        //die('i got dddhere');
        //to prevent empty field

        if($result = $conn->query($sqlstr)){
            //echo 'Success';
            echo "<script> alert('Update successful!');</script>";
            echo "<script> window.location.assign('registration.php'); </script>";
            

        }else{
            echo "<script> alert('Update failed!');</script>";
            // header("location: home.php?error=unknown error occurred&$user_data");
        }

    }
?>