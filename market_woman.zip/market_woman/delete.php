<?php
    $conn = new mysqli('localhost' , 'root' , '' , 'mr_abbey');
    
    if(isset($_GET['id'])){
        function validate($data){
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }
        $id = validate($_GET['id']);

        $sqlstr= "DELETE FROM market WHERE ID='$id'";
        //die('i got dddhere');
        //to prevent empty field

        if($result = $conn->query($sqlstr)){
            //echo 'Success';
            echo "<script> alert('Successfully deleted!');</script>";
            header("location: read.php?success=successfully deleted");

        }else{
            echo "<script> alert('Update failed!');</script>";
            // header("location: home.php?error=unknown error occurred&$user_data");
        }
    }else{
        header("location: read.php");
    }

?>