<?php
	    $bvn = $_POST['bvn'];
        $nin = $_POST['nin'];
        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $email = $_POST['email'];
        $address = $_POST['address'];
    $conn = new mysqli('localhost' , 'root' , '' , 'mr_abbey');
    if($conn->connect_error){

        die('Connection Failed : ' .$conn->connect_error);

    }else{
        //die('fdfdf');
        $sqlstr = "INSERT INTO market (bvn, nin, firstname, lastname, email, `address`) VALUES('$bvn', '$nin', '$firstname', '$lastname', '$email', '$address')";
        //die('i got dddhere');
        //to prevent empty field

        if($result = $conn->query($sqlstr)){
            //echo 'Success';
            
            echo "<script> alert('Registration successful!');</script>";
            echo "<script> window.location.assign('registration.php'); </script>";
            

        }else{
            echo "<script> alert('Registration failed!');</script>";
            // header("location: home.php?error=unknown error occurred&$user_data");
        }

    }
?>