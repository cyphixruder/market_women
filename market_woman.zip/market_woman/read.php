<?php include "readit.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.0.1-dist/css/bootstrap.css">
    <title>Document</title>
    <style>
        body{
            background-image: url(read.jpg);
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
        }
        .container{
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }
        .container form{
            width: 500px;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.2);
        }
    </style>
</head>
<body>

 
    <center>
        <div class="container">
            <div class="box">
                <h4 class="display-4 text-center">Read</h4><hr>
                <?php  if(mysqli_num_rows($result)){

                ?>
                <table class="table table-dark " style="border-radius: 15px !important;">
                    <thead>
                        <tr>
                        <th scope="col">S/N</th>
                        <th scope="col">bvn</th>
                        <th scope="col">nin</th>
                        <th scope="col">firstname</th>
                        <th scope="col">lastname</th>
                        <th scope="col">email</th>
                        <th scope="col">address</th>
                        <th scope="col">action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php   
                            $i = 0;
                            while($rows = mysqli_fetch_assoc($result)){
                            $i++;
                            $id = trim($rows['ID']);

                            
                        ?>
                        <tr>
                        <th scope="row"><?=$i?></th>
                        <td><?=$rows['bvn']?></td>
                        <td><?php echo $rows['nin']; ?></td>
                        <td><?php echo $rows['firstname']; ?></td>
                        <td><?php echo $rows['lastname']; ?></td>
                        <td><?php echo $rows['email']; ?></td>
                        <td><?php echo $rows['address']; ?></td>
                        <td><a href="update.php?id=<?php echo $id ?>" class="btn btn-success">Update</a>
                            <a href="delete.php?id=<?php echo $id ?>" class="btn btn-danger">Delete</a>
                        </td>
                        </tr>
                        <?php   } ?>
                    </tbody>
                </table>
                <?php }  ?>
                <div class="link-right">
                    <a href="registration.php" class="btn btn-primary" style="width: 10%; font-size: larger;">Create</a>
                </div>
            </div>
        </div>
    </center>
</body>
</html>