<?php
    $conn = new mysqli('localhost' , 'root' , '' , 'mr_abbey');
    if($conn->connect_error){

        die('Connection Failed : ' .$conn->connect_error);


    }else{
        
        $sql = "SELECT * FROM market  ORDER BY id DESC";
        $result = mysqli_query($conn, $sql);

    }

   
?>