<?php
    //die($_GET['id']);
?>
<?php   include 'updater.php' ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.0.1-dist/css/bootstrap.css">
    <title>Update</title>
    <style>
        body{
            background-image: url(mirror.jpg);
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
        }
        .container{
            width: 40%;
            background-color: #292929;
            margin-top: 5em;
            margin-bottom: 5em;
            padding-top: 4em;
            padding-bottom: 4em;
            border-radius: 10px;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }
        .ink{
            width: 80%;
        }
        .btn-success{
            margin-left: 2em;
        }
        .btn-success a{
            text-decoration: none;
            color: white;
            font-size: 18px;
        }
        .btn-success a:hover{
            text-decoration: none;
            color: white;
        }
        button{
            width: 35%;
            height: 50px;
        }
    </style>
</head>

<body>
    <center>
        <div class="container">
            <div class="ink">
            <h4 class="display-4 text-center" style="color: white;">MARKET WOMEN UPDATE FORM</h4><hr style="color: white; border: 2px solid white;">
                <form action="db_connect.php?id=<?php echo $_GET['id']; ?>" method="POST">
                    <div class="form-floating mb-3">
                        <input type="text" class="form-control" name="bvn" id="floatingtext" value="<?=$row['bvn'] ?>">
                        <label for="bvn">Bank Verification Number(BVN)</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="text" class="form-control" name="nin" id="floatingtext" value="<?=$row['nin'] ?>">
                        <label for="nin">National Identity Number(NIN)</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="text" class="form-control" name="firstname" value="<?=$row['firstname'] ?>">
                        <label for="firstname">First Name</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="text" class="form-control" name="lastname" value="<?=$row['lastname'] ?>">
                        <label for="lastname">Last Name</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="email" class="form-control" name="email" id="floatingtext" value="<?=$row['email'] ?>">
                        <label for="email">Your Email Addressr</label>
                    </div>
                    <div class="form-floating mb-3">
                        <textarea name="address" id="floatingtext" class="form-control" cols="87" rows="5" style="height: 100px !important;" value="<?=$row['address'] ?>"></textarea>
                        <label for="address">Address</label>
                    </div>
                    <button type="submit" class="btn btn-primary">Update</button>
                </form>
            </div>
        </div>
    </center>
</body>
</html>