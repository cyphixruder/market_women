<?php
$conn = new mysqli('localhost' , 'root' , '' , 'mr_abbey');
if($conn->connect_error){

    die('Connection Failed : ' .$conn->connect_error);

}else{
    
    //To retrieve data from database into the update form

    if(isset($_GET['id'])){
        function validate($data){
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }
        $id = validate($_GET['id']);

        $sql = "SELECT * FROM market  WHERE ID=$id";
        $result = mysqli_query($conn, $sql);

        if(mysqli_num_rows($result) > 0){
            $row = mysqli_fetch_assoc($result);
        }
    }else{
        header("location: read.php");
        //echo 'hi'; exit;
    }

}